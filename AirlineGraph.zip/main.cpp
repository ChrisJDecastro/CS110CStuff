#include "AirlinesGraph.h"

int main()
{
  AirlinesGraph graph;
  graph.computeCheapestPath();
  return 0;
}
 
 
